/*
 * TRANSACTION state handling.
 */

#ifndef _POP_TRANS_H
#define _POP_TRANS_H

extern int do_pop_trans(char *spool, char *mailbox);

#endif
