/*
 * popa3d version information.
 */

char popa3d_version[] = "1.0.3";
char popa3d_date[] = "2012/08/15";
