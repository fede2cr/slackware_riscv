rm -rf tcp_wrappers_7.6
tar xzf tcp_wrappers_7.6.tar.gz
cd tcp_wrappers_7.6
chown -R root.root .
cat ../tcpw7.2-config.patch | patch -p1 --verbose
cat ../tcpw7.2-setenv.patch | patch -p1 --verbose
cat ../tcpw7.6-netgroup.patch | patch -p1 --verbose
cat ../tcp_wrappers-7.6-bug11881.patch | patch -p1 --verbose
cat ../tcp_wrappers-7.6-bug17795.patch | patch -p1 --verbose
cat ../tcp_wrappers-7.6-bug17847.patch | patch -p1 --verbose
cat ../tcp_wrappers-7.6-fixgethostbyname.patch | patch -p1 --verbose
cat ../tcp_wrappers-7.6-docu.patch | patch -p1 --verbose
cat ../tcp_wrappers-7.6-casesens.patch | patch -p1 --verbose
cat ../tcp_wrappers.usagi-ipv6.patch | patch -p0 --verbose
cat ../tcp_wrappers.ume-ipv6.patch | patch -p1 --verbose
cat ../tcp_wrappers-7.6-shared.patch | patch -p1 --verbose
cat ../tcp_wrappers-7.6-sig.patch | patch -p1 --verbose
cat ../tcp_wrappers-7.6-strerror.patch | patch -p1 --verbose
cat ../tcp_wrappers-7.6-slackconfig.patch | patch -p1 --verbose

