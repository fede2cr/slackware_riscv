/*
 * String to embed in binaries to identify package
 */

char pkg[]="$NetKit: netkit-rwho-0.17 $";
