/*
 * String to embed in binaries to identify package
 */

char pkg[]="$NetKit: netkit-ntalk-0.17 $";
