/*
 * String to embed in binaries to identify package
 */

char pkg[]="$NetKit: biff+comsat-0.17 $";
