int daemon(int nochdir, int noclose);

