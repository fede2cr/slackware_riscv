/* -*- Mode: C; tab-width: 8; indent-tabs-mode: t; c-basic-offset: 8 -*- */
#ifndef __PARINTRF_H__
#define __PARINTRF_H__

#include "../base/newspost.h"

SList *par_newspost_interface(newspost_data * data, SList * file_list);

#endif /* __PARINTRF_H__ */
