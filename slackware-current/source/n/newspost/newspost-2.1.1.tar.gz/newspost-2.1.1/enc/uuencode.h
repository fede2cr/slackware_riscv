/* -*- Mode: C; tab-width: 8; indent-tabs-mode: t; c-basic-offset: 8 -*- */
#ifndef __UUENCODE_H__
#define __UUENCODE_H__

long uu_encode(FILE *infile, char *outbuf, int maxlines);

#endif /* __UUENCODE_H__ */
