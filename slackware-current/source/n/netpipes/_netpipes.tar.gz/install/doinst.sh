( cd usr/bin ; rm -rf getsockname )
( cd usr/bin ; ln -sf getpeername getsockname )
