
                                 Tix Tools
                                      
  [1]tix-man2html.tcl -- Man pages to HTML Convert Ousterhout format man pages
  into highly crosslinked hypertext.
  
  [2]hanno.tcl -- An HTML Annotation Program
  
   hanno.tcl automatically generates a "Last Modified" tag for HTML
   files. It recursively traverses all sub-directories and generates a
   "Last Modified" tag for each HTML file according to the file's last
   modification date. Please read the file for available options.
   
  [3]tcltrim
  
   tcltrim trims all comments and white spaces from TCL files.
   
  [4]tixindex
  
   tixindex builds the tclIndex file for the Tix widget implementation
   files. You must use this program to index the Tix librarys instead of
   the normal TCL auto_mkindex command.
   
  [5]color.tcl
  
   color.tcl displays all the available colors in your X display. This
   program requires tixwish.

References

   1. file://localhost/path/to/tix/tools/tix-man2html.tcl
   2. file://localhost/path/to/tix/tools/hanno.tcl
   3. file://localhost/path/to/tix/tools/tcltrim
   4. file://localhost/path/to/tix/tools/tixindex
   5. file://localhost/path/to/tix/tools/color.tcl
