/*
 *  Found this in termio.h on some unix machines.
 *  Changed to fit Linux's defaults.
 */

#ifdef __linux__
#define SSPEED	B9600	/* default speed */
/*
 *  Making any of the following an unconditional define will override system
 *  default values.
 */
#define CNUL    0

#ifndef CERASE
#define CERASE  127	/* ^? */
#endif

#ifndef CKILL
#define CKILL   025	/* ^U */
#endif

#ifndef CINTR
#define CINTR   03	/* ^C */
#endif

#ifndef CQUIT
#define CQUIT   034     /* ^\ */
#endif

#ifndef CSTART
#define CSTART  021     /* ^Q */
#endif

#ifndef CSTOP
#define CSTOP   023     /* ^S */
#endif

#ifndef CEOF
#define CEOF    04      /* ^D */
#endif

#ifndef CMIN
#define CMIN    06      /* satisfy read at 6 chars */
#endif

#ifndef CTIME
#define CTIME   01      /* .1 sec inter-character timer */
#endif

#endif
