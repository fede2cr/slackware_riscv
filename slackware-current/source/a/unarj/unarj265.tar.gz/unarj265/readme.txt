
   README.TXT                                                 June 2002


   This archive contains UNARJ version 2.65.

   This software as originally released by the author comes in an ARJ
   self-extracting archive with an ARJ-SECURITY envelope to prevent
   tampering.  Re-archival of this software will lose this security
   feature.


   THIS ARCHIVE CONTAINS THE FOLLOWING FILES:

   UNARJ265.EXE - An ARJ-SECURED self-extracting archive containing the
          following files:

          README.TXT     - this file
          UNARJ.EXE      - UNARJ executable for MS-DOS
          UNARJ32.EXE    - UNARJ executable for Windows 95/98/NT
          UNARJ.TXT      - UNARJ user manual
          UNARJ.C        - C source file
          DECODE.C       - C source file
          ENVIRON.C      - C source file
          UNARJ.H        - C include file
          TCCUNARJ.MAK   - TC++ makefile
          BCCUNARJ.MAK   - BC++ makefile
          BCC32.MAK      - BC++ 32 bit makefile
          QCLUNARJ.MAK   - QuickC makefile
          OS2UNARJ.MAK   - OS/2 BC++ makefile
          BCC32.CFG      - Borland C++ 5 configuration file
          TURBOC.CFG     - Borland C++ 3 configuration file
          TECHNOTE.TXT   - technical information about ARJ

   end of readme.doc
