# In order to properly handle time before /usr is mounted (in
# the event that /usr is a separate partition, which for a number
# of reasons isn't really a great idea), the /etc/localtime file
# should be a copy of the desired zoneinfo file and not a symlink
# to a file in /usr/share/zoneinfo. But if we find a symlink here
# we should defer to the admin's wishes and leave it alone.
#
# Note that setting the timezone with timeconfig will wipe both
# /etc/localtime and /etc/localtime-copied from.
# /etc/localtime-copied-from will be a symlink to a file under
# /usr/share/zoneinfo, and /etc/localtime will be a copy of that file.

# If we have no /etc/localtime, but we do have a localtime-copied-from
# symlink to locate what we would want there, then add a copy now:
if [ ! -r etc/localtime -a -L etc/localtime-copied-from ]; then
  chroot . /bin/cp etc/localtime-copied-from etc/localtime
fi
# Add the default timezone in /etc, if none exists:
if [ ! -r etc/localtime -a ! -L /etc/localtime-copied-from ]; then
  ( cd etc ; rm -rf localtime localtime-copied-from )
  ( cd etc ; ln -sf /usr/share/zoneinfo/Factory localtime-copied-from )
fi
# Make sure /etc/localtime is updated, unless it is a symlink (in which
# case leave it alone):
if [ ! -L etc/localtime ]; then
  chroot . /bin/cp etc/localtime-copied-from etc/localtime
fi
# Add a link to the timeconfig script in /usr/share/zoneinfo:
( cd usr/share/zoneinfo ; rm -rf timeconfig )
( cd usr/share/zoneinfo ; ln -sf /usr/sbin/timeconfig timeconfig )
### Make the rest of the symbolic links in the zoneinfo database:
