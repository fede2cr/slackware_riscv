chroot . /usr/bin/glib-compile-schemas /usr/share/glib-2.0/schemas/ 2>/dev/null 1>/dev/null
