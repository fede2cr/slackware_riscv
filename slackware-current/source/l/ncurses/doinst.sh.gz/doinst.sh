# Remove possible residue from ncurses-5.x:
rm -f usr/lib/libncurses.so.5
rm -f usr/lib/libncursesw.so.5
